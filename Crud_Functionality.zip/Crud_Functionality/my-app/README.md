# AdminPro - Product Inventory Management Dashboard

A modern, responsive admin dashboard for managing product inventory with full CRUD functionality. Built with React, Tailwind CSS, and localStorage for data persistence.

## Project Overview

**AdminPro** is a lightweight, single-page application designed for small to medium-sized businesses to manage their product catalog efficiently. It provides an intuitive interface for adding, editing, deleting, and viewing products with real-time updates and comprehensive filtering capabilities.

## 🎯 Project Objectives

- **Simplify Inventory Management**: Provide an easy-to-use interface for managing products without complex backend dependencies
- **Real-time Data Persistence**: Store product data locally using browser localStorage for instant availability
- **Professional UI/UX**: Create a modern, responsive design that works seamlessly across desktop and mobile devices
- **Scalability**: Build a foundation that can be easily extended with backend integration, authentication, or advanced features

## ✨ Key Features

### Dashboard Overview
- **Total Products Count**: Quick view of all products in inventory
- **Category Tracking**: Track the number of unique product categories
- **Inventory Valuation**: Calculate total value based on product price and stock quantity
- **Recently Added Products**: Display latest additions to the catalog with key metrics

### Product Management
- **View All Products**: Comprehensive product table with search and filter capabilities
- **Add Products**: Create new products with name, category, price, stock quantity, and image URL
- **Edit Products**: Modify existing product details with pre-filled form data
- **Delete Products**: Remove products from inventory with confirmation dialog
- **Search & Filter**: Find products by name, description, or category

### Data Management
- **Local Storage**: All data persists in the browser's localStorage (survives page refresh)
- **Form Validation**: Comprehensive validation for product fields (required fields, numeric validation)
- **Stock Status Indicators**: Visual indicators showing stock levels (green for >10, yellow for 1-10, red for 0)
- **Image Preview**: Display product images directly in the inventory list and form preview

## 🛠️ Tech Stack

- **Frontend Framework**: React 19.2.4
- **Styling**: Tailwind CSS 4.2.1 + Tailwind Play CDN
- **Routing**: React Router DOM 7.13.1
- **Icons**: Lucide React 0.575.0
- **State Management**: React Hooks (useState, useEffect)
- **Data Persistence**: Browser localStorage
- **Build Tool**: Create React App (react-scripts 5.0.1)

## 📁 Project Structure

```
my-app/
├── public/
│   ├── index.html       # Main HTML template with Tailwind CDN
│   └── manifest.json    # PWA metadata
├── src/
│   ├── components/
│   │   ├── DashboardCard.jsx      # Reusable dashboard metric card
│   │   ├── Navbar.jsx              # Top navigation bar
│   │   ├── ProductForm.jsx          # Product add/edit form with validation
│   │   ├── ProductTable.jsx         # Product inventory table with actions
│   │   └── Sidebar.jsx              # Left sidebar navigation
│   ├── pages/
│   │   ├── AddEditProduct.jsx      # Add/Edit product page
│   │   ├── Dashboard.jsx            # Dashboard overview page
│   │   └── Products.jsx             # Products inventory page
│   ├── utils/
│   │   └── localStorageHelper.js   # Utility functions for data persistence
│   ├── App.js           # Main app component with routing
│   ├── index.js         # React entry point
│   ├── index.css        # Global styles (Tailwind directives)
│   └── setupTests.js    # Test configuration
├── tailwind.config.js   # Tailwind CSS configuration with custom animations
├── postcss.config.js    # PostCSS configuration
├── package.json         # Project dependencies
└── README.md            # This file
```

## 🚀 Getting Started

### Prerequisites
- Node.js (v14 or higher)
- npm (v6 or higher)

### Installation

1. **Clone or extract the project**
   ```bash
   cd my-app
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the development server**
   ```bash
   npm start
   ```
   The app will open automatically at [http://localhost:3000](http://localhost:3000)

## Available Scripts

In the project directory, you can run:

### `npm start`
Runs the app in development mode with hot reload enabled.
- Open [http://localhost:3000](http://localhost:3000) to view in your browser
- Page automatically reloads on code changes
- Console displays lint errors and warnings

### `npm run build`
Builds the app for production into the `build/` folder.
- Code is minified and optimized for best performance
- Build is ready for deployment

### `npm test`
Launches the test runner in interactive watch mode.
- Runs tests defined in `*.test.js` files
- See [Create React App testing documentation](https://facebook.github.io/create-react-app/docs/running-tests) for details

### `npm run eject`
**Note: this is a one-way operation. Once you eject, you cannot go back!**

Exposes all build configuration and dependencies (use only if necessary).

## 💾 Data Persistence

All product data is stored in **browser localStorage** under the key `admin_dashboard_products`. 

### Benefits
- No backend server required for development
- Instant data persistence across page refreshes
- Perfect for prototyping and demonstrations

### Important Notes
- Data is local to each browser; clearing browser data will erase all products
- For production, replace localStorage with a proper backend API
- localStorage has a ~5-10MB limit per domain

## 🎨 Styling & Customization

### Tailwind CSS Configuration
Tailwind CSS is configured in `tailwind.config.js` with:
- Custom `fade-in-up` animation for page transitions
- Extended color palette from Tailwind defaults
- Responsive breakpoints for mobile, tablet, and desktop views

### Key Tailwind Classes Used
- `bg-indigo-*`: Primary action buttons and highlights
- `text-gray-*`: Text hierarchy and secondary elements
- `border-gray-*`: Subtle dividers and borders
- `shadow-sm`: Depth and card styling
- `rounded-lg`: Modern border radius

### Custom Animation
```css
.animate-fade-in-up {
  animation: fade-in-up 0.5s ease-out forwards;
}
```
Applied to main content areas for smooth page transitions.

## 🔧 Component Overview

### Pages
- **Dashboard**: Statistics, recent products, and quick navigation
- **Products**: Full inventory view with search and filter
- **AddEditProduct**: Form for adding or editing products

### Key Components
- **ProductForm**: Reusable form component with validation
- **ProductTable**: Sortable table with edit/delete actions
- **DashboardCard**: Metric display card component
- **Sidebar**: Navigation menu with responsive mobile support
- **Navbar**: Top navigation bar with sidebar toggle

## 📝 Features in Detail

### Product Fields
- **Name** (required): Product title
- **Category** (required): Product category for filtering
- **Price** (required): Numeric price value in dollars
- **Stock Quantity** (required): Numeric inventory count
- **Description** (optional): Detailed product information
- **Image URL** (optional): External image link with live preview

### Form Validation
- Required fields checked before submission
- Numeric validation for price and stock
- User-friendly error messages
- Real-time error clearing on input

### Dashboard Calculations
- **Total Products**: Count of all products
- **Total Categories**: Unique product categories
- **Total Inventory Value**: Sum of (price × stock quantity)
- **Recent Products**: Last 5 added products

## 🌐 Deployment

### Build for Production
```bash
npm run build
```

### Deploy Options
- **Vercel** (recommended): Connect your Git repo to Vercel for automatic deployments
- **Netlify**: Drag-and-drop the `build/` folder or connect Git
- **GitHub Pages**: Configure for GitHub Pages deployment
- **Traditional Hosting**: Upload `build/` folder contents to any static host

## 🐛 Troubleshooting

### Port 3000 Already in Use
```bash
npm start -- --port 3001
```

### Clear localStorage
Open browser DevTools → Application → Local Storage → Select your domain → Delete All

### Rebuild Node Modules
```bash
rm -r node_modules package-lock.json
npm install
```

## 🚀 Future Enhancements

- **Backend Integration**: Replace localStorage with REST API
- **Authentication**: Add user login and role-based access
- **Export Features**: CSV/PDF export of inventory reports
- **Advanced Filtering**: Multiple filters, sorting, pagination
- **Product Images**: Upload images instead of using URLs
- **Bulk Operations**: Add/edit/delete multiple products at once
- **Inventory Alerts**: Low stock notifications
- **Analytics**: Sales charts and product performance metrics
- **Mobile App**: React Native version for mobile devices

## 📞 Support & Contributing

For issues or feature requests, please:
1. Check existing documentation
2. Review the component code comments
3. Test in different browsers
4. Clear cache and verify reproducibility

## 📄 License

This project is open source and available under the MIT License.

---

## Learn More

- [React Documentation](https://reactjs.org/)
- [Tailwind CSS Docs](https://tailwindcss.com/docs)
- [React Router Documentation](https://reactrouter.com/)
- [Create React App Documentation](https://facebook.github.io/create-react-app/docs/getting-started)

